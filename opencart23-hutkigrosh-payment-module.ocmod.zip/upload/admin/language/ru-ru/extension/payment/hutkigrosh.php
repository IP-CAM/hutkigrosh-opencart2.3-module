<?php

$_['heading_title'] = 'HutkiGrosh';

$_['text_hutkigrosh'] = '<img src="view/image/payment/hgrosh.png" alt="Расчёт (ЕРИП)" title="Расчёт (ЕРИП)" style="border: 1px solid #EEEEEE;" />';
$_['text_payment'] = 'Оплата';
$_['text_success'] = 'Настройки модуля обновлены!';

$_['text_test'] = 'Режим песочницы:';
$_['text_status'] = 'Статус:';
$_['text_enabled'] = 'Включено';
$_['text_disabled'] = 'Отключено';
$_['text_save'] = 'Сохранить';
$_['text_cancel'] = 'Отмена';

$_['module_sort_order_label'] = 'Порядок сортировки';
$_['module_sort_order_description'] = 'Определяет порядок отображения модулей оплаты клиенту';
$_['module_status_label'] = 'Статус';
$_['module_status_description'] = 'Разрешен ли прием платежей через данный модуль';
$_['module_status_enable'] = 'Включен';
$_['module_status_disable'] = 'Выключен';

// Error
$_['error_permission'] = 'Внимание: у вас нет прав для редактирования модуля оплаты!';